from django.db import models
import datetime
from django.conf import settings

# Create your models here.
class Tipo(models.Model):
    idTipo = models.IntegerField(primary_key=True,verbose_name='Id')
    nombreTipo = models.CharField(max_length=50,verbose_name='Tipo')

    def __str__(self):
        return self.nombreTipo


class Usuario(models.Model):
    usuario = models.CharField(max_length=10,primary_key=True, verbose_name='usuario')
    nombre = models.CharField(max_length=10, verbose_name='nombre')
    contrasenha = models.CharField(max_length=10,null=True, blank=True, verbose_name='contraseña' )
    tipo = models.ForeignKey(Tipo, on_delete=models.CASCADE)

    def __str__(self):
        return self.usuario


class Categoria(models.Model):
    id=models.AutoField(primary_key=True, verbose_name="ID Categoria")
    nombre=models.CharField(max_length=50,verbose_name="Nombre Categoria")

    def __str__(self):
        return self.nombre


class Producto(models.Model):
    id = models.AutoField(primary_key=True,verbose_name="ID Producto")
    nombre = models.CharField(max_length=20,verbose_name="Nombre")
    descripcion = models.CharField(max_length=200, verbose_name="Descripción")
    stock = models.IntegerField(verbose_name="Stock", default=0)
    precio=models.IntegerField(verbose_name="Precio")
    foto=models.ImageField(upload_to='users/%Y/%m/%d/', height_field=None, width_field=None, max_length=100, verbose_name="Foto")
    descuento=models.IntegerField(verbose_name="Porcentaje de oferta", default=0)
    categoria=models.ForeignKey(Categoria, on_delete=models.CASCADE)

    def __str__(self):
        return self.nombre


class Sub(models.Model):
    TYPE_CHOICES = (('gratis','Gratis'), ('pago','Pago'))

    idUser = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, primary_key=True, unique=False)
    tipo = models.CharField(max_length=10, choices=TYPE_CHOICES, verbose_name="Tipo suscripción")
    inicio = models.DateField(default=datetime.date.today, verbose_name="Inicio suscripción")
    final = models.DateField(default=datetime.date.today, verbose_name="Final suscripción")

    def __str__(self):
        return self.idUser.username
