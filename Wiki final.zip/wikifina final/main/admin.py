from django.contrib import admin
from .models import Tipo, Usuario, Categoria, Producto, Sub
# Register your models here.
admin.site.register(Tipo)
admin.site.register(Usuario)
admin.site.register(Categoria)
admin.site.register(Producto)
admin.site.register(Sub)