from main.models import Sub


def total_carrito(request):
    total = 0
    if "carrito" in request.session.keys():
        user = request.user
        sub, created=Sub.objects.get_or_create(idUser=user)
        for key, value in request.session["carrito"].items():
            if sub.tipo == "pago":
                total += round(int(value["acumulado"])-(int(value["acumulado"])*0.05))
                mensaje = "Se ha aplicado el descuento de suscriptor, el total es: "
            else:
                total += int(value["acumulado"])
                mensaje = "El total es: "
    return {"total_carrito": total}