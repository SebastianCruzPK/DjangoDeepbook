import re
from django.shortcuts import render, redirect
from .forms import UsuarioForm, UserCreationForm
from .models import Tipo, Usuario, Categoria, Producto, Sub
from rest_framework import viewsets
from rest_usuario.serializers import UserSerializers, ProductoSerializers, CategoriaSerializers, SubSerializer
from django.contrib.auth.models import User
import requests
from django.http import Http404
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib import messages
from rest_framework.authtoken.models import Token
import datetime
from main.Carrito import Carrito


class SubViewSet(viewsets.ModelViewSet):
    queryset = Sub.objects.all()
    serializer_class = SubSerializer

class CategoriaViewSet(viewsets.ModelViewSet):
    queryset = Categoria.objects.all()
    serializer_class = CategoriaSerializers

class ProductoViewSet(viewsets.ModelViewSet):
    queryset = Producto.objects.all()
    serializer_class = ProductoSerializers

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializers

    
# Create your views here.
def home(request):
    return render(request,"main/index.html")

def index(request):
    return render(request,"main/index.html")

def crear(request):
    user = request.user
    context={'form':UserCreationForm}
    if request.method=='POST':
        formulario=UserCreationForm(request.POST)
        if formulario.is_valid():  
            formulario.save()
            user = authenticate(username=formulario.cleaned_data["username"], password=formulario.cleaned_data["password1"])
            Sub.objects.create(idUser=user, tipo="gratis", inicio=str(datetime.date.today()), final=str(datetime.date.today()))
            if user is not None:
                login(request, user)
                return redirect(to="wiki.html")
        else:
            print("Error. Ya existe")
        context['form'] = formulario
    return render(request,"registration/crear.html", context)

def populares(request):
    return render(request,"main/populares.html")
def problema(request):
    return render(request,"main/problema.html")
def recientes(request):
    return render(request,"main/recientes.html")
def voyatenersuerte(request):
    return render(request,"main/voyatenersuerte.html")
def wiki(request):
    return render(request,"main/wiki.html")
@permission_required('main.view_usuario')
def form_usuario(request):
    usuario = requests.get('http://127.0.0.1:8000/api/usuarios',  headers={'Authorization': 'Token 7fe7ac45e60d862401b825bc7c98aa4d82826dfe'}).json()
    datos = {
        'usuario':usuario,
        'form':UsuarioForm
    }
    if (request.method == 'POST'):
            formulario = UsuarioForm(request.POST)
            if formulario.is_valid():
                formulario.save()
                datos['mensaje'] = 'Guardados correctamente'
    return render(request,"main/form_usuario.html", datos)
def form_mod_usu(request, id):
    usuario = User.objects.get(id=id)
    datos={
        'form':UsuarioForm(instance=usuario)
    }
    if (request.method == 'POST'):
        formulario = UsuarioForm(data=request.POST, instance=usuario)
        if formulario.is_valid():
            formulario.save()
            datos['mensaje'] = 'Datos modificados correctamente'
    return render(request, 'main/form_mod_usu.html', datos)

def form_del_usu(request, id):
    usuario = User.objects.get(id=id)
    usuario.delete()
    return redirect(to='form_usuario')

def tienda(request):
    response = requests.get('http://127.0.0.1:8000/api/productos',  headers={'Authorization': 'Token 7fe7ac45e60d862401b825bc7c98aa4d82826dfe'}).json()
    contexto = {
        'productos':response
    }
    return render(request,"main/tienda.html", contexto)


def agregar_producto(request, producto_id):
    carrito = Carrito(request)
    producto = Producto.objects.get(id=producto_id)
    carrito.agregar(producto)
    return redirect('carrito')

def eliminar_producto(request, producto_id):
    carrito = Carrito(request)
    producto = Producto.objects.get(id=producto_id)
    carrito.eliminar(producto)
    return redirect('carrito')

def restar_producto(request, producto_id):
    carrito = Carrito(request)
    producto = Producto.objects.get(id=producto_id)
    carrito.restar(producto)
    return redirect('carrito')

def limpiar_carrito(request):
    carrito = Carrito(request)
    carrito.limpiar()
    return redirect('carrito')


def comprar(request):
    carrito = Carrito(request)
    carrito.comprar()
    return redirect('main/wiki.html')

def carrito(request):
    response=requests.get('http://127.0.0.1:8000/api/productos',  headers={'Authorization': 'Token 7fe7ac45e60d862401b825bc7c98aa4d82826dfe'}).json()
    return render(request, 'main/carrito.html', {'productos':response})

def comprar(request):
    carrito = Carrito(request)
    carrito.comprar()
    return redirect('../tienda.html')


