from dataclasses import fields
from django import forms
from django.forms import ModelForm
from .models import Usuario
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


class UsuarioForm(ModelForm):
    class Meta:
        model = User
        fields = ['username', 'password']


class CustomCreationForm(UserCreationForm):
    pass