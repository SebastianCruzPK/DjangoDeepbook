from cgitb import html
from django.conf import settings
from django.conf.urls.static import static
from unicodedata import name
from django.urls import path, include
from .forms import UsuarioForm
from .views import home, index, crear, populares, problema, recientes, voyatenersuerte, wiki, form_usuario, form_mod_usu, form_del_usu, agregar_producto, eliminar_producto, restar_producto, limpiar_carrito, tienda, carrito, comprar





urlpatterns = [
    path('', home, name="home"),
    path('index.html', index, name="index"),
    path('crear.html', crear, name="crear"),
    path('populares.html', populares, name="populares"),
    path('problema.html', problema, name="problema"),
    path('recientes.html', recientes, name="recientes"),
    path('voyatenersuerte.html', voyatenersuerte, name="voyatenersuerte"),
    path('wiki.html', wiki, name="wiki"),
    path('form_usuario.html', form_usuario, name="form_usuario"),
    path('form_mod_usu.html/<id>', form_mod_usu, name="form_mod_usu"),
    path('form_del_usu.html/<id>', form_del_usu, name="form_del_usu"),
    path('tienda.html', tienda, name="tienda"),
    path('agregar/<int:producto_id>/', agregar_producto, name="Add"),
    path('eliminar/<int:producto_id>/', eliminar_producto, name="Del"),
    path('restar/<int:producto_id>/', restar_producto, name="Sub"),
    path('limpiar/', limpiar_carrito, name="CLS"),
    path('carrito.html', carrito, name="carrito"),
    path('comprar/', comprar, name="comprar"),

    
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
