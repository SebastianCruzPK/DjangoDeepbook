from rest_framework import serializers
from main.models import Producto, Usuario, Categoria, Sub
from django.contrib.auth.models import User
from datetime import datetime

date = datetime.today()

class Usuarioserializers(serializers.ModelSerializer):
    class Meta:
        model = Usuario
        fields = ['usuario', 'nombre', 'contrasenha', 'tipo']

class ProductoSerializers(serializers.ModelSerializer):

    total = serializers.SerializerMethodField('totalfunc')
    
    def totalfunc(self, prod):
        return round(prod.precio - (prod.precio * (prod.descuento/100)))

    class Meta:
        model = Producto
        fields = ['id', 'nombre', 'descripcion', 'precio', 'foto', 'descuento', 'categoria', 'stock', 'total']
    
class CategoriaSerializers(serializers.ModelSerializer):
    class Meta:
        model = Categoria
        fields = '__all__'

class UserSerializers(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'



class SubSerializer(serializers.ModelSerializer):
    activo = serializers.SerializerMethodField('estado_sub')
    
    def estado_sub(self, sub):
        if int(sub.final.strftime('%Y%m%d')) > int(date.strftime('%Y%m%d')):
            membership=Sub.objects.get(idUser=sub.idUser)
            membership.tipo = "pago"
            membership.save()
            return True
        else:
            membership=Sub.objects.get(idUser=sub.idUser)
            membership.tipo = "gratis"
            membership.save()
            return False

    
    username=serializers.CharField(source="idUser.username")

    class Meta:
        model = Sub
        fields = ['idUser', 'username', 'tipo', 'inicio', 'final', 'activo']