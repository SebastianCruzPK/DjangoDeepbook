from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_usuario.views import lista_usuario ,detalle_usuario
from rest_usuario.viewsLogin import loginapi

urlpatterns = [
    path('lista_usuario', lista_usuario, name = "lista_usuario"),
    path('detalle_usuario/<id>', detalle_usuario, name = "detalle_usuario"),
    path('login', loginapi, name='loginapi'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)